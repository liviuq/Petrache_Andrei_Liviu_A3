#pragma once

#include <iostream>

class Carte
{
private:

public:
	virtual std::string GetInfo() = 0;
};

